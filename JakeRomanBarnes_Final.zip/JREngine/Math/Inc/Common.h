#ifndef INCLUDED_MATH_COMMON_H
#define INCLUDED_MATH_COMMON_H

#include <Core/Inc/Core.h>

#endif // #ifndef INCLUDED_MATH_COMMON_H