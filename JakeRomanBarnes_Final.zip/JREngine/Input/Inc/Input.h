#ifndef INCLUDED_INPUT_H
#define INCLUDED_INPUT_H


#include "Common.h"

#include "InputTypes.h"
#include "InputSystem.h"

#endif // #ifndef INCLUDED_INPUT_H